

public class SearchResult {
    private String title, url,summary;
    public SearchResult(String title, String url, String summary)
    {
        this.title=title;
        this.url=url;
        this.summary=summary;
    }

    public String getTitle()
    {
        return title;
    }
    public String getUrl()
    {
        return url;
    }
    public String getSummary()
    {
        return summary;
    }
}
