import requests
import pytz
from apscheduler.schedulers.twisted import TwistedScheduler
from twisted.internet import reactor


def send_request():
    requests.post("https://shielded-badlands-57155.herokuapp.com/schedule.json", data={
        'project': 'default',
        'spider': 'airbnb',
        'city': 'San Francisco'
    })


if __name__ == '__main__':
    scheduler = TwistedScheduler(timezone=pytz.utc)
    scheduler.add_job(send_request, 'cron',
                      day_of_week='mon-sun', hour='22', minute='50')
    scheduler.start()
    reactor.run()
