# -*- coding: utf-8 -*-
import scrapy
from scrapy.exceptions import CloseSpider
from scrapy.loader import ItemLoader
from demo_airbnb.items import DemoAirbnbItem
from scrapy.loader.processors import TakeFirst
import json


class AirbnbSpider(scrapy.Spider):
    name = 'airbnb'
    allowed_domains = ['www.airbnb.com']

    def start_requests(self):
        yield scrapy.Request(url='https://www.airbnb.com/api/v2/explore_tabs?version=1.3.9&satori_version=1.0.7&_format=for_explore_search_web&experiences_per_grid=20&items_per_grid=18&guidebooks_per_grid=20&auto_ib=false&fetch_filters=true&has_zero_guest_treatment=false&is_guided_search=true&is_new_cards_experiment=true&luxury_pre_launch=false&query_understanding_enabled=true&show_groupings=true&supports_for_you_v3=true&timezone_offset=120&client_session_id=e44973e0-2a63-4e3d-9e9c-75e7708f5f3a&metadata_only=false&is_standard_search=true&refinement_paths%5B%5D=%2Frestaurants&selected_tab_id=restaurant_tab&adults=1&children=0&infants=0&guests=1&screen_size=large&query={0}&_intents=p1&key=d306zoyjsyarp7ifhu67rjxn52tv0t20&currency=USD&locale=en'.format(self.city), callback=self.parse_id)

    def parse_id(self, response):
        data = json.loads(response.body)

        restaurants = data.get('explore_tabs')[0].get(
            'sections')[0].get('recommendation_items')

        if restaurants is None:
            raise CloseSpider('No restaurant is available in this city')

        for restaurant in restaurants:
            yield scrapy.Request(url='https://www.airbnb.com/api/v2/place_activities/{0}?key=d306zoyjsyarp7ifhu67rjxn52tv0t20&currency=USD&locale=en&_format=for_spa_activity_pdp_web'.format(restaurant.get('id')), callback=self.parse)

        pagination_metadata = data.get('explore_tabs')[
            0].get('pagination_metadata')

        if pagination_metadata.get('has_next_page'):
            items_offset = pagination_metadata.get('items_offset')
            section_offset = pagination_metadata.get('section_offset')
            yield scrapy.Request(url='https://www.airbnb.com/api/v2/explore_tabs?version=1.3.9&satori_version=1.0.7&_format=for_explore_search_web&experiences_per_grid=20&items_per_grid=18&guidebooks_per_grid=20&auto_ib=false&fetch_filters=true&has_zero_guest_treatment=false&is_guided_search=true&is_new_cards_experiment=true&luxury_pre_launch=false&query_understanding_enabled=true&show_groupings=true&supports_for_you_v3=true&timezone_offset=120&client_session_id=e44973e0-2a63-4e3d-9e9c-75e7708f5f3a&metadata_only=false&is_standard_search=true&refinement_paths%5B%5D=%2Frestaurants&selected_tab_id=restaurant_tab&adults=1&children=0&infants=0&guests=1&screen_size=large&query={2}&_intents=p1&key=d306zoyjsyarp7ifhu67rjxn52tv0t20&currency=USD&locale=en&items_offset={0}&section_offset={1}'.format(items_offset, section_offset, self.city), callback=self.parse_id)

    def parse(self, response):
        loader = ItemLoader(item=DemoAirbnbItem(), response=response)
        loader.default_output_processor = TakeFirst()
        restaurant = json.loads(response.body).get('place_activity')
        loader.add_value("_id", restaurant.get('id'))
        loader.add_value("title", restaurant.get('title'))
        loader.add_value("_type", restaurant.get('action_kicker'))
        loader.add_value("description", restaurant.get('description'))
        loader.add_value("address", restaurant.get('place').get('address'))
        loader.add_value("city", restaurant.get('place').get('city'))
        loader.add_value("country", restaurant.get('place').get('country'))
        loader.add_value("latitude", restaurant.get('place').get('lat'))
        loader.add_value("longitude", restaurant.get('place').get('lng'))
        loader.add_value("phone_number", restaurant.get('place').get('phone'))
        loader.add_value("website", restaurant.get('place').get('website'))

        yield loader.load_item()
