# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html


from pymongo import MongoClient
from scrapy.exceptions import DropItem
import random
import string
import xlsxwriter
from demo_airbnb.items import DemoAirbnbItem


class MongoDbPipeline(object):
    collection = ''

    def __init__(self, mongo_uri, mongo_db):
        self.mongo_uri = mongo_uri
        self.mongo_db = mongo_db

    @classmethod
    def from_crawler(cls, crawler):
        return cls(
            mongo_uri=crawler.settings.get('MONGO_URI'),
            mongo_db=crawler.settings.get('MONGO_DB')
        )

    def open_spider(self, spider):
        self.client = MongoClient(self.mongo_uri)
        self.db = self.client[self.mongo_db]

        self.collection = spider.city

    def close_spider(self, spider):
        self.client.close()

    def process_item(self, item, spider):
        if self.db[self.collection].count_documents({"_id": item.get("_id")}) == 1:
            raise DropItem("Item dropped")
        else:
            self.db[self.collection].insert_one(dict(item))
            return item


class XlsxPipeline(object):

    def __init__(self):
        self.airbnb_obj = DemoAirbnbItem()
        self.row = 1
        self.col = 0


    def open_spider(self, spider):
        self.workbook= xlsxwriter.Workbook(filename=f"{spider.name}-{random.randint(1,1000)}.xlsx")
        bold = self.workbook.add_format({'bold': 1})
        self.spreadsheet = self.workbook.add_worksheet()
        self.fields = self.airbnb_obj.fields.keys()
        alphabet = list(string.ascii_uppercase)[1:len(self.fields)]

        for field, letter in zip(self.fields, alphabet):
            self.spreadsheet.write(f"{letter}1", field, bold)
        


    def close_spider(self, spider):
        self.workbook.close()

    def process_item(self, item, spider):
        for field in self.fields:
            self.spreadsheet.write(self.row, self.col, item.get(field))
            self.col += 1
        self.row += 1
        self.col = 0
        return item
